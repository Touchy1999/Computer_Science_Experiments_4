#!/usr/bin/env python2

import sys
import rospy
import std_srvs.srv import *

def client():
    rospy.wait_for_service('start_game')
    try:
        service = rospy.ServiceProxy('start_game', Empty)
        service()
    except rospy.ServiceException, e:
        rospy.logerr("Error Message : %s", %e)

if __name__ == "__main__":
    client()
