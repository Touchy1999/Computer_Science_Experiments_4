#!/usr/bin/env python  
import rospy
import math
import tf2_ros
import geometry_msgs.msg
import nav_msgs.msg
import sensor_msgs.msg
import numpy as np
import tf
import cv2
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from std_srvs.srv import *
from sensor_msgs.msg import Image
from sensor_msgs.msg import CameraInfo
from cv_bridge import CvBridge, CvBridgeError
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist

cmd_vel = Twist()
destination_angle = 0
nz = []

"""
## definition of convert_angle to make a robot move linearly
def convert_angle(angle):
  if angle > math.pi:
    return angle - 2*math.pi
  else:
    return angle
"""

## definition of callback3
def callback3(data):
  global destination_angle
  global nz
  f = 265.23
  u0 = 160.5
  x, y, w, h = cv2.boundingRect(nz)
  u = x + w/2
  destination_angle = math.atan2(u-u0, f)
  """
  fx = data.K[0]
  u0 = data.K[2]
  fy = data.K[4]
  v0 = data.K[5]
  z = 0.25
  destination_x = z*(u-u0)/fx
  destination_y = z*(v-v0)/fy
  """

## definition of callback2 for velocity and angular velocity
def callback2(data):
  global cmd_vel
  global pub
  global destination_angle
  v_max = 0.25
  cmd_vel.linear.x = v_max
  cmd_vel.angular.z = -destination_angle
  pub.publish(cmd_vel)

def callbackImage(msg):
  global pub2, bridge
  global nz
  try:
    cv_image = bridge.imgmsg_to_cv2(msg, "bgr8")
    low = (0, 0, 0)  # detecting red
    high = (50, 50, 255)
    masked_image = cv2.inRange(cv_image, low, high)
    nz = cv2.findNonZero(masked_image)
  except CvBridgeError as e:
    rospy.logerr(e)
  # process image - for example, draw a circle
  (rows,cols,channels) = cv_image.shape
  if cols > 60 and rows > 60 :
    cv2.circle(cv_image, (50,50), 10, 255)
  # plot image
  cv2.imshow("Processed image", masked_image)
  cv2.waitKey(3)
  # convert to ROS format and publish
  try:
    pub2.publish(bridge.cv2_to_imgmsg(cv_image, "bgr8"))
  except CvBridgeError as e:
    rospy.logerr(e)

def main():
  global pub2
  global bridge
  global pub
  rospy.init_node('image_converter', anonymous=True)
  sub3 = rospy.Subscriber("camera/camera_info", CameraInfo, callback3)
  sub = rospy.Subscriber("odom", Odometry, callback2)
  sub2 = rospy.Subscriber("camera/image", Image, callbackImage)
  pub = rospy.Publisher('cmd_vel', Twist, queue_size=10)
  pub2 = rospy.Publisher("/processed/image", Image, queue_size=5)
  bridge = CvBridge()
  tfBuffer = tf2_ros.Buffer()
  listener = tf2_ros.TransformListener(tfBuffer)
  rate = rospy.Rate(20)
  while not rospy.is_shutdown():
      try:
        trans_from_odom_into_base_link = tfBuffer.lookup_transform("base_link", "odom", rospy.Time(0))
        # trans_from_base_scan_into_odom = tfBuffer.lookup_transform("odom", "base_scan", rospy.Time(0))
      except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException):
        rate.sleep()
        continue
      # pub.publish(cmd_vel)
      cv2.destroyAllWindows()
      rate.sleep()

if __name__ == '__main__':
  main()